from typing import Dict


ANSWER_DICT_TYPE = Dict[str, str]
ANSWER_BOOK_TYPE = Dict[str, ANSWER_DICT_TYPE]
